import com.sap.gateway.ip.core.customdev.util.Message
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.text.SimpleDateFormat
import java.util.TimeZone
import javax.xml.parsers.DocumentBuilderFactory
import javax.xml.transform.TransformerFactory
import javax.xml.transform.OutputKeys
import javax.xml.transform.dom.DOMSource
import javax.xml.transform.stream.StreamResult
import java.io.ByteArrayInputStream
import java.io.StringWriter

Message processData(Message message) {
    def log = messageLogFactory.getMessageLog(message)
    def formattedDate

    try {
        // NTP config
        def ntpServer = "aravo1.set.gov.py"
        def ntpPort = 123
        def timeoutMs = 5000
        def ntpEpochOffset = 2208988800L

        def socket = new DatagramSocket()
        socket.setSoTimeout(timeoutMs)
        def address = InetAddress.getByName(ntpServer)

        byte[] request = new byte[48]
        request[0] = 0x1B
        socket.send(new DatagramPacket(request, request.length, address, ntpPort))

        byte[] response = new byte[48]
        def responsePacket = new DatagramPacket(response, response.length)
        socket.receive(responsePacket)
        socket.close()

        long secondsSince1900 = 0
        for (int i = 40; i < 44; i++) {
            secondsSince1900 = (secondsSince1900 << 8) | (response[i] & 0xFF)
        }

        long unixTime = secondsSince1900 - ntpEpochOffset
        def ntpDate = new Date(unixTime * 1000L)
        formattedDate = formatDate(ntpDate)
        log?.addAttachmentAsString("NTP Time Used", formattedDate, "text/plain")

    } catch (Exception e) {
        // Fallback to system time
        def fallbackDate = new Date()
        formattedDate = formatDate(fallbackDate)
        log?.addAttachmentAsString("Fallback Time Used", formattedDate, "text/plain")
        log?.addAttachmentAsString("NTP Error", e.getMessage(), "text/plain")
    }

    // Replace <dFecFirma>
    def body = message.getBody(String) as String
    def dbf = DocumentBuilderFactory.newInstance()
    dbf.setNamespaceAware(true)
    def doc = dbf.newDocumentBuilder().parse(new ByteArrayInputStream(body.getBytes("UTF-8")))

    def nodeList = doc.getElementsByTagName("dFecFirma")
    if (nodeList.getLength() > 0) {
        nodeList.item(0).setTextContent(formattedDate)
    }

    // Serialize XML without declaration
    def transformer = TransformerFactory.newInstance().newTransformer()
    transformer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes") // ← key change
    transformer.setOutputProperty(OutputKeys.INDENT, "no")

    def writer = new StringWriter()
    transformer.transform(new DOMSource(doc), new StreamResult(writer))
    message.setBody(writer.toString())

    return message
}

// Fixed UTC-3 timezone
String formatDate(Date date) {
    def sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss")
    sdf.setTimeZone(TimeZone.getTimeZone("GMT-3:00"))
    return sdf.format(date)
}
