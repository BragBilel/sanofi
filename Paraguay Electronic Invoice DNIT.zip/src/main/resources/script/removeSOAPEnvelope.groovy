import com.sap.gateway.ip.core.customdev.util.Message 
import javax.xml.parsers.DocumentBuilderFactory
import javax.xml.transform.TransformerFactory
import javax.xml.transform.OutputKeys
import javax.xml.transform.dom.DOMSource
import javax.xml.transform.stream.StreamResult
import java.io.ByteArrayInputStream
import java.io.StringWriter

Message processData(Message message) {
    def body = message.getBody(String) as String
    def dbf = DocumentBuilderFactory.newInstance()
    dbf.setNamespaceAware(true)
    def doc = dbf.newDocumentBuilder().parse(new ByteArrayInputStream(body.getBytes("UTF-8")))

    def ns = "http://ekuatia.set.gov.py/sifen/xsd"
    def targetNode = null

    def nodeList = doc.getElementsByTagNameNS(ns, "rRetEnviDe")
    if (nodeList != null && nodeList.getLength() > 0) {
        targetNode = nodeList.item(0)
    } else {
        nodeList = doc.getElementsByTagNameNS(ns, "rEnviConsDeResponse")
        if (nodeList != null && nodeList.getLength() > 0) {
            targetNode = nodeList.item(0)
        }
    }

    def transformer = TransformerFactory.newInstance().newTransformer()
    transformer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes")
    transformer.setOutputProperty(OutputKeys.ENCODING, "UTF-8")
    transformer.setOutputProperty(OutputKeys.INDENT, "no")

    def writer = new StringWriter()
    transformer.transform(new DOMSource(targetNode), new StreamResult(writer))

    message.setBody(writer.toString())
    return message
}

