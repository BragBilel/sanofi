import com.sap.gateway.ip.core.customdev.util.Message 
import com.sap.it.api.ITApiFactory
import com.sap.it.api.securestore.SecureStoreService
import com.sap.it.api.securestore.UserCredential

import javax.xml.parsers.DocumentBuilderFactory
import javax.xml.xpath.XPathConstants
import javax.xml.xpath.XPathFactory

import java.io.ByteArrayOutputStream
import java.io.InputStream
import java.security.MessageDigest

import org.apache.xml.security.utils.XMLUtils

def Message processData(Message message) {
    def factory = DocumentBuilderFactory.newInstance()
    factory.setNamespaceAware(true)
    def doc = factory.newDocumentBuilder().parse(message.getBody(InputStream))
    def xpath = XPathFactory.newInstance().newXPath()

    def getText = { String path ->
        xpath.evaluate(path, doc, XPathConstants.STRING) as String
    }

    def dVerFor = getText("//*[local-name()='dVerFor']")
    def idDE = getText("//*[local-name()='DE']/@Id")
    def dFeEmiDE = getText("//*[local-name()='dFeEmiDE']")
    def dRucRec = getText("//*[local-name()='dRucRec']")
    def dNumIDRec = getText("//*[local-name()='dNumIDRec']")
    def dTotOpe = getText("//*[local-name()='dTotGralOpe']") ?: "0"
    def dTotIVA = getText("//*[local-name()='dTotIVA']") ?: "0"
    def digestValue = getText("//*[local-name()='DigestValue']")
    def cItems = doc.getElementsByTagNameNS("*", "gCamItem").getLength().toString()

    def toHex = { value ->
        value?.getBytes("UTF-8")?.encodeHex()?.toString()
    }

    def dFeEmiHex = toHex(dFeEmiDE)
    def digestHex = toHex(digestValue)

    def credentialName = message.getProperty("companyCSC") as String
    SecureStoreService secureStoreService = ITApiFactory.getApi(SecureStoreService.class, null)
    UserCredential userCredential = secureStoreService.getUserCredential(credentialName)
    def idCSC = userCredential.getUsername()
    def codigoSecreto = new String(userCredential.getPassword())

    // Elegir cuál ID usar
    def idReceptorClave
    def idReceptorValor

    if (dRucRec?.trim()) {
        idReceptorClave = "dRucRec"
        idReceptorValor = dRucRec
    } else if (dNumIDRec?.trim()) {
        idReceptorClave = "dNumIDRec"
        idReceptorValor = dNumIDRec
    } else {
        throw new RuntimeException("Ni dRucRec ni dNumIDRec están presentes en el XML.")
    }

    def qrBaseString = "nVersion=${dVerFor}&Id=${idDE}&dFeEmiDE=${dFeEmiHex}&${idReceptorClave}=${idReceptorValor}" +
                       "&dTotGralOpe=${dTotOpe}&dTotIVA=${dTotIVA}&cItems=${cItems}" +
                       "&DigestValue=${digestHex}&IdCSC=${idCSC}${codigoSecreto}"

    MessageDigest digest = MessageDigest.getInstance("SHA-256")
    byte[] hashBytes = digest.digest(qrBaseString.getBytes("UTF-8"))
    def hashHex = hashBytes.encodeHex().toString()

    def systemType = message.getProperty("systemType") as String
    def url = (systemType == "PROD")
        ? "https://ekuatia.set.gov.py/consultas/qr?"
        : "https://ekuatia.set.gov.py/consultas-test/qr?"

    def qrURLRaw = "${url}nVersion=${dVerFor}&Id=${idDE}&dFeEmiDE=${dFeEmiHex}&${idReceptorClave}=${idReceptorValor}" +
                   "&dTotGralOpe=${dTotOpe}&dTotIVA=${dTotIVA}&cItems=${cItems}" +
                   "&DigestValue=${digestHex}&IdCSC=${idCSC}&cHashQR=${hashHex}"

    def dCarQR = doc.createElement("dCarQR")
    dCarQR.setTextContent(qrURLRaw)

    def gCamFuFDList = doc.getElementsByTagNameNS("*", "gCamFuFD")
    if (gCamFuFDList.getLength() > 0) {
        def oldGCamFuFD = gCamFuFDList.item(0)
        def parent = oldGCamFuFD.getParentNode()
        def nextSibling = oldGCamFuFD.getNextSibling()
        def dInfAdicList = oldGCamFuFD.getElementsByTagNameNS("*", "dInfAdic")
        def dInfAdic = (dInfAdicList.getLength() > 0) ? dInfAdicList.item(0).cloneNode(true) : null

        parent.removeChild(oldGCamFuFD)

        def newGCamFuFD = doc.createElement("gCamFuFD")
        newGCamFuFD.appendChild(dCarQR)
        if (dInfAdic != null) {
            newGCamFuFD.appendChild(dInfAdic)
        }

        if (nextSibling != null) {
            parent.insertBefore(newGCamFuFD, nextSibling)
        } else {
            parent.appendChild(newGCamFuFD)
        }
    }

    def outputStream = new ByteArrayOutputStream()
    XMLUtils.outputDOM(doc, outputStream)
    message.setBody(outputStream.toString())
    return message
}
