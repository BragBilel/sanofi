import com.sap.gateway.ip.core.customdev.util.Message
import com.sap.it.api.ITApiFactory
import com.sap.it.api.keystore.KeystoreService

import org.apache.xml.security.Init
import org.w3c.dom.Element

import java.io.ByteArrayOutputStream
import java.io.InputStream
import java.security.cert.X509Certificate
import java.util.Collections
import java.util.List
import java.util.Arrays

import javax.xml.parsers.DocumentBuilderFactory
import javax.xml.crypto.dsig.CanonicalizationMethod
import javax.xml.crypto.dsig.DigestMethod
import javax.xml.crypto.dsig.Reference
import javax.xml.crypto.dsig.SignatureMethod
import javax.xml.crypto.dsig.SignedInfo
import javax.xml.crypto.dsig.Transform
import javax.xml.crypto.dsig.XMLSignatureFactory
import javax.xml.crypto.dsig.dom.DOMSignContext
import javax.xml.crypto.dsig.keyinfo.KeyInfo
import javax.xml.crypto.dsig.keyinfo.KeyInfoFactory
import javax.xml.crypto.dsig.keyinfo.X509Data
import javax.xml.crypto.dsig.spec.C14NMethodParameterSpec
import javax.xml.crypto.dsig.spec.TransformParameterSpec
import javax.xml.transform.Transformer
import javax.xml.transform.TransformerFactory
import javax.xml.transform.dom.DOMSource
import javax.xml.transform.stream.StreamResult

def Message processData(Message message) { 
    Init.init()

    def factory = DocumentBuilderFactory.newInstance()
    factory.setNamespaceAware(true)
    def doc = factory.newDocumentBuilder().parse(message.getBody(InputStream))
    def alias = message.getProperty("companyAlias") as String
    def keystore = ITApiFactory.getService(KeystoreService, null)
    def privateKey = keystore.getKeyPair(alias).getPrivate()
    def cert = (X509Certificate) keystore.getCertificate(alias)

    def sigFactory = XMLSignatureFactory.getInstance("DOM")

    Transform envelopedTransform = sigFactory.newTransform(Transform.ENVELOPED, (TransformParameterSpec) null)
    Transform c14nTransform = sigFactory.newTransform("http://www.w3.org/2001/10/xml-exc-c14n#", (TransformParameterSpec) null)
    List<Transform> transforms = Arrays.asList(envelopedTransform, c14nTransform)

    Element nodeToSign = (Element) doc.getElementsByTagName("DE").item(0)
    String id = nodeToSign.getAttribute("Id")
    nodeToSign.setIdAttribute("Id", true)

    DigestMethod digestMethod = sigFactory.newDigestMethod(DigestMethod.SHA256, null)
    Reference reference = sigFactory.newReference("#" + id, digestMethod, transforms, null, null)

    CanonicalizationMethod canonicalizationMethod = sigFactory.newCanonicalizationMethod(CanonicalizationMethod.EXCLUSIVE, (C14NMethodParameterSpec) null)
    SignatureMethod signatureMethod = sigFactory.newSignatureMethod("http://www.w3.org/2001/04/xmldsig-more#rsa-sha256", null)
    SignedInfo signedInfo = sigFactory.newSignedInfo(canonicalizationMethod, signatureMethod, Collections.singletonList(reference))

    KeyInfoFactory kif = sigFactory.getKeyInfoFactory()
    X509Data x509Data = kif.newX509Data(Collections.singletonList(cert))
    KeyInfo keyInfo = kif.newKeyInfo(Collections.singletonList(x509Data))
 
    def signContext = new DOMSignContext(privateKey, nodeToSign.getParentNode(), nodeToSign.getNextSibling())
    def signature = sigFactory.newXMLSignature(signedInfo, keyInfo)
    signature.sign(signContext)

    ByteArrayOutputStream outputStream = new ByteArrayOutputStream()
    Transformer transformer = TransformerFactory.newInstance().newTransformer()
    transformer.transform(new DOMSource(doc), new StreamResult(outputStream))
    String signedXml = outputStream.toString("UTF-8")

    message.setBody(signedXml)
    return message
}
