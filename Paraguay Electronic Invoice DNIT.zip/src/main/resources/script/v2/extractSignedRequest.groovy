// This Groovy Flowstep Version 2, running with Groovy 4, Downgrade the script if older behaviour needed.

import com.sap.it.script.v2.api.Message
import java.util.Base64
import javax.xml.parsers.DocumentBuilderFactory
import java.io.ByteArrayInputStream
import java.io.StringWriter
import javax.xml.transform.TransformerFactory
import javax.xml.transform.OutputKeys
import javax.xml.transform.dom.DOMSource
import javax.xml.transform.stream.StreamResult
import javax.xml.xpath.XPathFactory
import javax.xml.xpath.XPathConstants

Message processData(Message message) {
    def body = message.getBody(String) as String

    def dbf = DocumentBuilderFactory.newInstance()
    dbf.setNamespaceAware(true)
    def soapDoc = dbf.newDocumentBuilder().parse(new ByteArrayInputStream(body.getBytes("UTF-8")))

    def xpath = XPathFactory.newInstance().newXPath()
    def expr = xpath.compile("//*[local-name()='xContenDE']")
    def node = expr.evaluate(soapDoc, XPathConstants.NODE)

    if (node == null || node.textContent == null || node.textContent.trim().isEmpty()) {
        return message
    }

    def xmlEscaped = node.textContent

    def xmlDecoded = xmlEscaped
        .replaceAll('&lt;', '<')
        .replaceAll('&gt;', '>')
        .replaceAll('&amp;', '&')
        .replaceAll('&apos;', "'")
        .replaceAll('&quot;', '"')
        .replaceFirst(/<\?xml[^>]*\?>/, "")
        .trim()

    def rdeStart = xmlDecoded.indexOf("<rDE")
    def rdeEnd = xmlDecoded.indexOf("</rDE>") + "</rDE>".length()

    if (rdeStart == -1 || rdeEnd == -1) {
        return message
    }

    def rdeOnly = xmlDecoded.substring(rdeStart, rdeEnd)
    def safeXml = rdeOnly.replaceAll(/&(?!lt;|gt;|amp;|apos;|quot;)/, '&amp;')
    def rdeDoc = dbf.newDocumentBuilder().parse(new ByteArrayInputStream(safeXml.getBytes("UTF-8")))
    def rdeNode = rdeDoc.getDocumentElement()

    def transformer = TransformerFactory.newInstance().newTransformer()
    transformer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes")
    transformer.setOutputProperty(OutputKeys.ENCODING, "UTF-8")
    def writer = new StringWriter()
    transformer.transform(new DOMSource(rdeNode), new StreamResult(writer))
    def rdeXml = writer.toString()

    def base64Encoded = Base64.encoder.encodeToString(rdeXml.getBytes("UTF-8"))
    message.setProperty("signedRequest", base64Encoded)

    return message
}
