import com.sap.gateway.ip.core.customdev.util.Message
import groovy.util.XmlParser
import groovy.xml.XmlUtil

Message processData(Message message) { 
    def body = message.getBody(String) 
    def parser = new XmlParser(false, false)
    def root = parser.parseText(body)
 
    root.attributes().put('xmlns', 'http://ekuatia.set.gov.py/sifen/xsd')
    root.attributes().put('xmlns:xsi', 'http://www.w3.org/2001/XMLSchema-instance')
    root.attributes().put('xsi:schemaLocation', 'http://ekuatia.set.gov.py/sifen/xsd siRecepDE_v150.xsd')
 
    def updatedXml = XmlUtil.serialize(root) 
    updatedXml = updatedXml.replaceFirst(/<\?xml.*\?>\s*/, "")
 
    message.setBody(updatedXml) 
    return message
}
