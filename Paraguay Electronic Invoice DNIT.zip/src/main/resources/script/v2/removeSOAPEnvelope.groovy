// Groovy Flowstep Version 2, running with Groovy 4

import com.sap.it.script.v2.api.Message
import javax.xml.parsers.DocumentBuilderFactory
import javax.xml.transform.TransformerFactory
import javax.xml.transform.OutputKeys
import javax.xml.transform.dom.DOMSource
import javax.xml.transform.stream.StreamResult
import javax.xml.XMLConstants
import java.io.ByteArrayInputStream
import java.io.StringWriter

Message processData(Message message) {

    def body = message.getBody(String) as String 
    def dbf = DocumentBuilderFactory.newInstance()
    dbf.setNamespaceAware(true)

    // --- Security hardening: prevent XXE / external entity processing ---
    try { dbf.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true) } catch (Exception ignored) {}
    try { dbf.setFeature("http://xml.org/sax/features/external-general-entities", false) } catch (Exception ignored) {}
    try { dbf.setFeature("http://xml.org/sax/features/external-parameter-entities", false) } catch (Exception ignored) {}
    try { dbf.setFeature("http://apache.org/xml/features/nonvalidating/load-external-dtd", false) } catch (Exception ignored) {}

    try { dbf.setXIncludeAware(false) } catch (Exception ignored) {}
    try { dbf.setExpandEntityReferences(false) } catch (Exception ignored) {}

    try { dbf.setAttribute(XMLConstants.ACCESS_EXTERNAL_DTD, "") } catch (Exception ignored) {}
    try { dbf.setAttribute(XMLConstants.ACCESS_EXTERNAL_SCHEMA, "") } catch (Exception ignored) {}
    // ---------------------------------------------------------------

    def doc = dbf.newDocumentBuilder()
                 .parse(new ByteArrayInputStream(body.getBytes("UTF-8")))

    def ns = "http://ekuatia.set.gov.py/sifen/xsd"
    def nodeList = null

    nodeList = doc.getElementsByTagNameNS(ns, "rResEnviLoteDe")

    if (nodeList == null || nodeList.getLength() == 0) {
        nodeList = doc.getElementsByTagNameNS(ns, "rRetEnviDe")
    }

    if (nodeList == null || nodeList.getLength() == 0) {
        nodeList = doc.getElementsByTagNameNS(ns, "rEnviConsDeResponse")
    }

    if (nodeList == null || nodeList.getLength() == 0) {
        nodeList = doc.getElementsByTagNameNS(ns, "rResEnviConsLoteDe")
    }


    def targetNode = (nodeList != null && nodeList.getLength() > 0)
            ? nodeList.item(0)
            : null

    def transformer = TransformerFactory.newInstance().newTransformer()
    transformer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes")
    transformer.setOutputProperty(OutputKeys.ENCODING, "UTF-8")
    transformer.setOutputProperty(OutputKeys.INDENT, "no")

    def writer = new StringWriter()
    transformer.transform(new DOMSource(targetNode), new StreamResult(writer))

    message.setBody(writer.toString())
    return message
}
